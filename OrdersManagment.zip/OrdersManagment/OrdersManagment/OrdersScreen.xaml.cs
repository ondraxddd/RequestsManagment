﻿using OrdersManagment.Controllers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OrdersManagment
{
    /// <summary>
    /// Interaction logic for OrdersScreen.xaml
    /// </summary>
    public partial class OrdersScreen : Page
    {
        DataTable dataTable;

        public OrdersScreen()
        {
            InitializeComponent();

            objInfo.AutoGenerateColumns = false;

            DataGridCheckBoxColumn stateColumn = new DataGridCheckBoxColumn();
            stateColumn.Header = "Stav";
            stateColumn.Binding = new Binding("state");
            stateColumn.Width = new DataGridLength(0.5, DataGridLengthUnitType.Star);
            objInfo.Columns.Add(stateColumn);

            DataGridTextColumn productColumn = new DataGridTextColumn();
            productColumn.Header = "Zboží";
            productColumn.Binding = new Binding("product");
            productColumn.Width = new DataGridLength(2, DataGridLengthUnitType.Star);
            objInfo.Columns.Add(productColumn);

            DataGridTextColumn qnColumn = new DataGridTextColumn();
            qnColumn.Header = "Množství";
            qnColumn.Binding = new Binding("quantity");
            qnColumn.Width = new DataGridLength(1, DataGridLengthUnitType.Star);
            objInfo.Columns.Add(qnColumn);

            DataGridTextColumn customerColumn = new DataGridTextColumn();
            customerColumn.Header = "Zákazník";
            customerColumn.Binding = new Binding("customer");
            customerColumn.Width = new DataGridLength(1, DataGridLengthUnitType.Star);
            objInfo.Columns.Add(customerColumn);

            DataGridTextColumn contactColumn = new DataGridTextColumn();
            contactColumn.Header = "Kontakt";
            contactColumn.Binding = new Binding("contact");
            contactColumn.Width = new DataGridLength(1, DataGridLengthUnitType.Star);
            objInfo.Columns.Add(contactColumn);

            DataGridTextColumn noteColumn = new DataGridTextColumn();
            noteColumn.Header = "Poznámka";
            noteColumn.Binding = new Binding("note");
            noteColumn.Width = new DataGridLength(1.5, DataGridLengthUnitType.Star);
            objInfo.Columns.Add(noteColumn);

            DataGridTextColumn idColumn = new DataGridTextColumn();
            idColumn.Header = "id";
            idColumn.Binding = new Binding("id");
            idColumn.Width = new DataGridLength(0.5, DataGridLengthUnitType.Star);
            objInfo.Columns.Add(idColumn);

            
        }

        private void ShowOrders(long id)
        {
            if(id > -1)
            {
                string sqlCommand = $"SELECT * FROM requests WHERE did = {id} ORDER BY id DESC";
                dataTable = DbController.manager.GetData(sqlCommand);    
            }
            else
            {
                string sqlCommand = $"SELECT * FROM requests ORDER BY id DESC";
                dataTable = DbController.manager.GetData(sqlCommand);
            }
            objInfo.ItemsSource = dataTable.DefaultView;

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDealers();
        }

        private void LoadDealers()
        {
            comboD.DisplayMemberPath = "name";
            comboD.SelectedValuePath = "id";
            DataTable dataTable = DbController.manager.GetData("SELECT * FROM dealers");
            DataRow all = dataTable.NewRow();
            all["id"] = -1;
            all["name"] = "Všechno";
            dataTable.Rows.Add(all);
            comboD.ItemsSource = dataTable.DefaultView;
            if (dataTable.Rows.Count > 0) comboD.SelectedIndex = 0;
            ShowOrders((long)comboD.SelectedValue);
        }

        private void comboD_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(comboD.SelectedValue != null) ShowOrders((long)comboD.SelectedValue);
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            // Získání aktuálně označeného řádku v datagridu
            DataRowView selectedRow = (DataRowView)objInfo.SelectedItem;

            // Získání hodnoty z column "id" v aktuálně označeném řádku
            if (selectedRow != null)
            {
                EditWindow wn = new EditWindow(selectedRow);
                wn.ShowDialog();
                System.Threading.Thread.Sleep(350);
                ShowOrders((long)selectedRow["did"]);
            }


        }

        private void changeState_Click(object sender, RoutedEventArgs e)
        {
            // Získání aktuálně označeného řádku v datagridu
            DataRowView selectedRow = (DataRowView)objInfo.SelectedItem;

            // Získání hodnoty z column "id" v aktuálně označeném řádku
            if (selectedRow != null)
            {
                int id = int.Parse(selectedRow["id"].ToString());
                bool state = selectedRow["state"] is true ? false : true;
                string sqlCommand = $"UPDATE requests SET state = {state} WHERE id = {id};";
                DbController.manager.ExecuteNonQuery(sqlCommand);
                System.Threading.Thread.Sleep(300);
                ShowOrders((long)selectedRow["did"]);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            // Získání aktuálně označeného řádku v datagridu
            DataRowView selectedRow = (DataRowView)objInfo.SelectedItem;

            // Získání hodnoty z column "id" v aktuálně označeném řádku
            if (selectedRow != null)
            {
                int id = int.Parse(selectedRow["id"].ToString());
                string sqlCommand = $"DELETE FROM requests WHERE id = {id}";
                DbController.manager.ExecuteNonQuery(sqlCommand);
                System.Threading.Thread.Sleep(300);
                ShowOrders((long)selectedRow["did"]);
            }
        }
    }
    
}
