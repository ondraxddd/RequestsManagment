﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrdersManagment
{
    public interface IDbController
    {
        void Initialize();

        void ExecuteNonQuery(string sqlCommand);
        
        DataTable GetData(string sqlCommand);

    }
}
