﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrdersManagment.Controllers
{
    public static class DbController
    {
        public static IDbController manager = new SqliteController();

        public static string DbName { get; set; }

        public static string ConnectionString { get; set; }

    }
}
