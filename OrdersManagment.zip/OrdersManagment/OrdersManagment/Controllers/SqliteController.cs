﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace OrdersManagment.Controllers
{
    public class SqliteController : IDbController
    {
        private SQLiteConnection SqliteConnection { get; set; }

        public void Initialize()
        {
            DbController.DbName = "Database";
            DbController.ConnectionString = $"Data Source={DbController.DbName}.sqlite;Version=3";
            if (!DatabaseCheck())
            {
                MakeDatabase();
            }

        }

        private bool DatabaseCheck()
        {
            // check if the database exists
            if(!File.Exists(DbController.DbName + ".sqlite")) return false;                      

            // connect to the database
            SqliteConnection = new SQLiteConnection(DbController.ConnectionString);

            // check all the tables if exists

            return true;
        }

        private void MakeDatabase()
        {
            // create database file
            SQLiteConnection.CreateFile(DbController.DbName + ".sqlite");
            SqliteConnection = new SQLiteConnection(DbController.ConnectionString);

            // make tables
            string tableDealers = "CREATE TABLE dealers(id INTEGER PRIMARY KEY AUTOINCREMENT, name VARCHAR(60) NOT NULL)";
            ExecuteNonQuery(tableDealers);
            string tableRequests = "CREATE TABLE requests(id INTEGER PRIMARY KEY AUTOINCREMENT, did INTEGER NOT NULL, product VARCHAR(70), quantity VARCHAR(20), customer VARCHAR(70), contact VARCHAR(70), note VARCHAR(500), state BOOLEAN DEFAULT 0, FOREIGN KEY(did) REFERENCES dealers(id))";
            ExecuteNonQuery(tableRequests);
            string dealerNezarazeno = "INSERT INTO dealers(name) VALUES('Nezařazeno')";
            ExecuteNonQuery(dealerNezarazeno);

        }

        public void ExecuteNonQuery(string sqlCommand)
        {
            if(SqliteConnection.State != ConnectionState.Open)
            {
                SqliteConnection.Close();
                SqliteConnection.Open();
            }
            SQLiteCommand cmd = new SQLiteCommand(sqlCommand, SqliteConnection);
            cmd.ExecuteNonQuery();
            SqliteConnection.Close();
        }

        public DataTable GetData(string sqlCommand)
        {
            if (SqliteConnection.State != ConnectionState.Open)
            {
                SqliteConnection.Close();
                SqliteConnection.Open();
            }
            SQLiteCommand cmd = new SQLiteCommand(sqlCommand, SqliteConnection);
            DataTable dt = new DataTable();
            SQLiteDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            SqliteConnection.Close();
            return dt;
        }
    }
}
