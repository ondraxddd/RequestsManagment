﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrdersManagment
{
    public class Dealer
    {
        public long id;
        public string name;
    }
}
