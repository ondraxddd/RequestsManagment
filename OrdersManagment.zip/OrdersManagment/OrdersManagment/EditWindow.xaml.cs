﻿using OrdersManagment.Controllers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OrdersManagment
{
    /// <summary>
    /// Interaction logic for EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        int id;
        public EditWindow(DataRowView row)
        {
            InitializeComponent();
            boxProduct.Text = row["product"].ToString();
            boxQn.Text = row["quantity"].ToString();
            boxCustomer.Text = row["customer"].ToString();
            boxContact.Text = row["contact"].ToString();
            boxNote.Text = row["note"].ToString();
            id = int.Parse(row[id].ToString());
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            string sqlCommand = $"UPDATE requests SET product = '{boxProduct.Text}', quantity = '{boxQn.Text}'," +
                $"customer = '{boxCustomer.Text}', contact = '{boxContact.Text}', note = '{boxNote.Text}' WHERE id = {id}";
            DbController.manager.ExecuteNonQuery(sqlCommand);
            Close();
        }
    }
}
