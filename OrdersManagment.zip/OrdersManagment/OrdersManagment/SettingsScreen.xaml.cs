﻿using OrdersManagment.Controllers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OrdersManagment
{
    /// <summary>
    /// Interaction logic for SettingsScreen.xaml
    /// </summary>
    public partial class SettingsScreen : Page
    {
        public SettingsScreen()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDealers();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            string sqlCommand = $"DELETE FROM dealers WHERE id = {listDealers.SelectedValue}";
            DbController.manager.ExecuteNonQuery(sqlCommand);
            System.Threading.Thread.Sleep(350);
            sqlCommand = $"DELETE FROM requests WHERE did = {listDealers.SelectedValue}";
            DbController.manager.ExecuteNonQuery(sqlCommand);
            System.Threading.Thread.Sleep(350);
            LoadDealers();
        }

        private void LoadDealers()
        {
            listDealers.DisplayMemberPath = "name";
            listDealers.SelectedValuePath = "id";
            DataTable dataTable = DbController.manager.GetData("SELECT * FROM dealers");
            listDealers.ItemsSource = dataTable.DefaultView;
            if (dataTable.Rows.Count > 0) listDealers.SelectedIndex = 0;
        }
    }
}
