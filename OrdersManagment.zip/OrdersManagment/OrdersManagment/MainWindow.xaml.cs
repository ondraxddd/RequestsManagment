﻿using OrdersManagment.Controllers;
using OrdersManagment.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OrdersManagment
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        object HomeScreen;
        object OrdersScreen;
        object SettingsSc;

        public MainWindow()
        {
            InitializeComponent();
            HomeScreen = new HomeScreen();
            OrdersScreen = new OrdersScreen();
            SettingsSc = new SettingsScreen();
            DbController.manager.Initialize();            

            screen.Content = HomeScreen;
            
        }

        private void Zaviraci_Button_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }

        private void Minimalizacni_Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.WindowState = WindowState.Minimized;
            }
            catch
            {
                MessageBox.Show("Aplikaci zrovna nelze minimalizovat.");
            }
        }

        private void HorniLista_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            screen.Content = HomeScreen;
        }

        private void Pozadavky_Click(object sender, RoutedEventArgs e)
        {
            screen.Content = OrdersScreen;
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            screen.Content = SettingsSc;
        }
    }
}
