﻿using OrdersManagment.Controllers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OrdersManagment.Pages
{
    /// <summary>
    /// Interaction logic for HomeScreen.xaml
    /// </summary>
    public partial class HomeScreen : Page
    {
        public HomeScreen()
        {
            InitializeComponent();

            recentDataGrid.BorderThickness = new Thickness(2);
            recentDataGrid.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#9488FF"));
            recentDataGrid.AutoGenerateColumns = false;

            DataGridTextColumn productColumn = new DataGridTextColumn();
            productColumn.Header = "Zboží";
            productColumn.Binding = new Binding("product");
            productColumn.Width = new DataGridLength(0.5, DataGridLengthUnitType.Star);
            recentDataGrid.Columns.Add(productColumn);

            DataGridTextColumn qnColumns = new DataGridTextColumn();
            qnColumns.Header = "Množství";
            qnColumns.Binding = new Binding("quantity");
            qnColumns.Width = new DataGridLength(0.5, DataGridLengthUnitType.Star);
            recentDataGrid.Columns.Add(qnColumns);

            DataGridTextColumn customerColumn = new DataGridTextColumn();
            customerColumn.Header = "Zákazník";
            customerColumn.Binding = new Binding("customer");
            customerColumn.Width = new DataGridLength(0.5, DataGridLengthUnitType.Star);
            recentDataGrid.Columns.Add(customerColumn);

            DataGridTextColumn contactColumn = new DataGridTextColumn();
            contactColumn.Header = "Kontakt";
            contactColumn.Binding = new Binding("contact");
            contactColumn.Width = new DataGridLength(0.5, DataGridLengthUnitType.Star);
            recentDataGrid.Columns.Add(contactColumn);

            DataGridTextColumn dealerColumn = new DataGridTextColumn();
            dealerColumn.Header = "Dealer";
            dealerColumn.Binding = new Binding("dealer_name");
            dealerColumn.Width = new DataGridLength(0.5, DataGridLengthUnitType.Star);
            recentDataGrid.Columns.Add(dealerColumn);

        }

        private void btnAddDealer_Click(object sender, RoutedEventArgs e)
        {
            AddDealerWindow wn = new AddDealerWindow();
            wn.ShowDialog();
            LoadDealers();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
           

            LoadDealers();
            UpdateRecent();
        }

        private void LoadDealers()
        {
            cmBxSelectDealer.DisplayMemberPath = "name";
            cmBxSelectDealer.SelectedValuePath = "id";
            DataTable dataTable = DbController.manager.GetData("SELECT * FROM dealers");
            cmBxSelectDealer.ItemsSource = dataTable.DefaultView;
            if (dataTable.Rows.Count > 0) cmBxSelectDealer.SelectedIndex = 0;
        }

        private void UpdateRecent()
        {
            DataTable recentOrder = DbController.manager.GetData("SELECT r.id, d.name AS dealer_name, r.product, r.quantity, r.customer, r.contact, r.note " +
                "FROM requests r JOIN dealers d ON r.did = d.id ORDER BY r.id DESC " +
                "LIMIT 13");

            recentDataGrid.ItemsSource = recentOrder.DefaultView; 
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if(cmBxSelectDealer.SelectedItem != null)
            {
                if(product.Text.Length > 1 && qn.Text.Length > 0 && customer.Text.Length > 1 && contact.Text.Length > 1)
                {
                    string command = $"INSERT INTO requests(did, product, quantity, customer, contact, note) " +
                        $"VALUES('{cmBxSelectDealer.SelectedValue}', '{product.Text}','{qn.Text}', '{customer.Text}', '{contact.Text}', '{note.Text}')";
                    DbController.manager.ExecuteNonQuery(command);
                    UpdateRecent();
                }
                else
                {
                    MessageBox.Show("Vyplňte prosím všechny potřbné údaje.");
                }
            }
            else
            {
                MessageBox.Show("Pro přidání požadavku musíte vybrat dodavatele.");
            }
        }
    }
}
